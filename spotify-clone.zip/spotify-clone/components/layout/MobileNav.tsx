'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Search, Library } from 'lucide-react'
import { cn } from '@/lib/utils'

const links = [
  { href: '/',        label: 'Home',    icon: Home },
  { href: '/search',  label: 'Search',  icon: Search },
  { href: '/library', label: 'Library', icon: Library },
]

export function MobileNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0a0a0a] border-t border-[#282828] flex items-center justify-around px-2 pb-safe md:hidden"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      {links.map(({ href, label, icon: Icon }) => (
        <Link
          key={href}
          href={href}
          className={cn(
            'flex flex-col items-center gap-1 py-3 px-4 transition-colors min-w-0',
            pathname === href ? 'text-white' : 'text-[#727272] hover:text-[#b3b3b3]'
          )}
        >
          <Icon size={22} strokeWidth={pathname === href ? 2.5 : 1.8} />
          <span className="text-[10px] font-semibold tracking-wide">{label}</span>
        </Link>
      ))}
    </nav>
  )
}
