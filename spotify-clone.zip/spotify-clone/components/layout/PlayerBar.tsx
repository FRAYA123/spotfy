'use client'

import Image from 'next/image'
import {
  Play, Pause, SkipBack, SkipForward, Shuffle, Repeat, Repeat1,
  Volume2, VolumeX, Volume1, Heart, Maximize2, ListMusic, Mic2
} from 'lucide-react'
import { usePlayer } from '@/hooks/usePlayer'
import { cn } from '@/lib/utils'
import { formatTime } from '@/lib/utils'

export function PlayerBar() {
  const {
    currentSong, isPlaying, volume, progress, duration,
    isShuffle, repeatMode, isMuted, togglePlay, playNext, playPrev,
    toggleShuffle, cycleRepeat, setVolume, toggleMute, seek,
  } = usePlayer()

  if (!currentSong) return null

  const progressPercent = duration > 0 ? (progress / duration) * 100 : 0

  function handleProgressClick(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect()
    const ratio = (e.clientX - rect.left) / rect.width
    seek(ratio * duration)
  }

  function handleVolumeClick(e: React.MouseEvent<HTMLDivElement>) {
    const rect = e.currentTarget.getBoundingClientRect()
    const ratio = (e.clientX - rect.left) / rect.width
    setVolume(Math.max(0, Math.min(1, ratio)))
  }

  const VolumeIcon = isMuted || volume === 0 ? VolumeX : volume < 0.4 ? Volume1 : Volume2
  const coverSrc = currentSong.cover_url || currentSong.albums?.cover_url

  return (
    <footer className="h-[90px] bg-[#181818] border-t border-[#282828] flex items-center px-4 gap-4 z-50 flex-shrink-0">

      {/* Track info */}
      <div className="flex items-center gap-3 w-[30%] min-w-[180px]">
        <div className="relative w-14 h-14 rounded flex-shrink-0 overflow-hidden bg-[#282828]">
          {coverSrc ? (
            <Image src={coverSrc} alt={currentSong.title} fill className="object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Mic2 size={20} className="text-[#535353]" />
            </div>
          )}
        </div>
        <div className="overflow-hidden min-w-0">
          <p className="text-white text-sm font-semibold truncate hover:underline cursor-pointer">
            {currentSong.title}
          </p>
          <p className="text-[#b3b3b3] text-xs truncate hover:text-white hover:underline cursor-pointer transition-colors">
            {currentSong.artists?.name || 'Unknown Artist'}
          </p>
        </div>
        <button className="text-[#b3b3b3] hover:text-white transition-colors flex-shrink-0 ml-2">
          <Heart size={16} />
        </button>
      </div>

      {/* Player controls */}
      <div className="flex flex-col items-center gap-2 flex-1 max-w-[480px] mx-auto">
        <div className="flex items-center gap-5">
          {/* Shuffle */}
          <button
            onClick={toggleShuffle}
            className={cn(
              'relative transition-colors',
              isShuffle ? 'text-[#1DB954]' : 'text-[#b3b3b3] hover:text-white'
            )}
            title="Shuffle"
          >
            <Shuffle size={16} />
            {isShuffle && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#1DB954]" />
            )}
          </button>

          {/* Previous */}
          <button
            onClick={playPrev}
            className="text-[#b3b3b3] hover:text-white transition-colors"
            title="Previous"
          >
            <SkipBack size={20} fill="currentColor" />
          </button>

          {/* Play / Pause */}
          <button
            onClick={togglePlay}
            className="w-9 h-9 bg-white hover:scale-105 active:scale-95 rounded-full flex items-center justify-center transition-transform"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying
              ? <Pause size={17} fill="#000" color="#000" />
              : <Play size={17} fill="#000" color="#000" className="ml-0.5" />
            }
          </button>

          {/* Next */}
          <button
            onClick={playNext}
            className="text-[#b3b3b3] hover:text-white transition-colors"
            title="Next"
          >
            <SkipForward size={20} fill="currentColor" />
          </button>

          {/* Repeat */}
          <button
            onClick={cycleRepeat}
            className={cn(
              'relative transition-colors',
              repeatMode !== 'none' ? 'text-[#1DB954]' : 'text-[#b3b3b3] hover:text-white'
            )}
            title={`Repeat: ${repeatMode}`}
          >
            {repeatMode === 'one' ? <Repeat1 size={16} /> : <Repeat size={16} />}
            {repeatMode !== 'none' && (
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#1DB954]" />
            )}
          </button>
        </div>

        {/* Progress bar */}
        <div className="flex items-center gap-3 w-full">
          <span className="text-[#b3b3b3] text-[11px] tabular-nums min-w-[36px] text-right">
            {formatTime(progress)}
          </span>
          <div
            className="group flex-1 h-1 bg-[#535353] rounded-full cursor-pointer relative hover:h-[5px] transition-all duration-150"
            onClick={handleProgressClick}
            title="Seek"
          >
            <div
              className="absolute left-0 top-0 h-full bg-white group-hover:bg-[#1DB954] rounded-full transition-colors relative"
              style={{ width: `${progressPercent}%` }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 translate-x-1/2 transition-opacity" />
            </div>
          </div>
          <span className="text-[#b3b3b3] text-[11px] tabular-nums min-w-[36px]">
            {formatTime(duration)}
          </span>
        </div>
      </div>

      {/* Right controls */}
      <div className="w-[30%] flex items-center justify-end gap-3">
        <button className="text-[#b3b3b3] hover:text-white transition-colors hidden sm:block" title="Queue">
          <ListMusic size={16} />
        </button>

        {/* Volume */}
        <div className="flex items-center gap-2">
          <button
            onClick={toggleMute}
            className="text-[#b3b3b3] hover:text-white transition-colors"
          >
            <VolumeIcon size={16} />
          </button>
          <div
            className="group w-20 h-1 bg-[#535353] rounded-full cursor-pointer hover:h-[5px] transition-all duration-150 relative"
            onClick={handleVolumeClick}
          >
            <div
              className="h-full bg-white group-hover:bg-[#1DB954] rounded-full relative transition-colors"
              style={{ width: `${(isMuted ? 0 : volume) * 100}%` }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full opacity-0 group-hover:opacity-100 translate-x-1/2 transition-opacity" />
            </div>
          </div>
        </div>

        <button className="text-[#b3b3b3] hover:text-white transition-colors hidden md:block" title="Full screen">
          <Maximize2 size={15} />
        </button>
      </div>
    </footer>
  )
}
