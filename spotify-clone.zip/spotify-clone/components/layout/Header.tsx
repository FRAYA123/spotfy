'use client'

import { ChevronLeft, ChevronRight, User, LogOut, Settings } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { cn } from '@/lib/utils'
import { createClient } from '@/lib/supabase'
import type { User as AuthUser } from '@/types'

interface HeaderProps {
  scrolled?: boolean
  bgColor?: string
  user?: AuthUser | null
}

export function Header({ scrolled = false, bgColor = 'transparent', user }: HeaderProps) {
  const router = useRouter()
  const [menuOpen, setMenuOpen] = useState(false)

  async function handleSignOut() {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push('/login')
    router.refresh()
  }

  return (
    <header
      className={cn(
        'sticky top-0 z-40 flex items-center justify-between px-6 py-3 transition-all duration-300',
        scrolled ? 'bg-[#121212]/95 backdrop-blur-sm shadow-md' : 'bg-transparent'
      )}
      style={!scrolled && bgColor !== 'transparent' ? { backgroundColor: bgColor + 'cc' } : {}}
    >
      {/* Navigation arrows */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => router.back()}
          className="w-8 h-8 bg-black/70 hover:bg-black/90 rounded-full flex items-center justify-center text-white transition-colors"
          aria-label="Go back"
        >
          <ChevronLeft size={18} />
        </button>
        <button
          onClick={() => router.forward()}
          className="w-8 h-8 bg-black/70 hover:bg-black/90 rounded-full flex items-center justify-center text-white transition-colors"
          aria-label="Go forward"
        >
          <ChevronRight size={18} />
        </button>
      </div>

      {/* User menu */}
      <div className="relative">
        {user ? (
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="flex items-center gap-2 bg-[#282828] hover:bg-[#3e3e3e] rounded-full pl-1 pr-3 py-1 transition-colors"
          >
            <div className="w-7 h-7 bg-[#1DB954] rounded-full flex items-center justify-center text-black font-bold text-xs">
              {user.user_metadata?.full_name?.[0]?.toUpperCase() || user.email?.[0]?.toUpperCase() || 'U'}
            </div>
            <span className="text-white text-sm font-bold">
              {user.user_metadata?.full_name?.split(' ')[0] || 'User'}
            </span>
          </button>
        ) : (
          <div className="flex items-center gap-3">
            <a href="/signup" className="text-[#b3b3b3] hover:text-white text-sm font-semibold transition-colors">
              Sign up
            </a>
            <a
              href="/login"
              className="bg-white hover:bg-gray-100 text-black text-sm font-bold px-4 py-2 rounded-full transition-colors"
            >
              Log in
            </a>
          </div>
        )}

        {/* Dropdown menu */}
        {menuOpen && user && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
            <div className="absolute right-0 top-12 z-50 bg-[#282828] rounded-md shadow-2xl py-1 min-w-[160px] border border-white/10">
              <a
                href="/profile"
                className="flex items-center gap-3 px-4 py-2.5 text-sm text-[#b3b3b3] hover:text-white hover:bg-[#3e3e3e] transition-colors"
                onClick={() => setMenuOpen(false)}
              >
                <User size={16} />
                Profile
              </a>
              <a
                href="/settings"
                className="flex items-center gap-3 px-4 py-2.5 text-sm text-[#b3b3b3] hover:text-white hover:bg-[#3e3e3e] transition-colors"
                onClick={() => setMenuOpen(false)}
              >
                <Settings size={16} />
                Settings
              </a>
              <div className="my-1 h-px bg-[#3e3e3e]" />
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-3 px-4 py-2.5 text-sm text-[#b3b3b3] hover:text-white hover:bg-[#3e3e3e] transition-colors text-left"
              >
                <LogOut size={16} />
                Log out
              </button>
            </div>
          </>
        )}
      </div>
    </header>
  )
}
