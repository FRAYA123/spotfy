'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Search, Library, PlusSquare, Heart, Music2 } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Playlist } from '@/types'

interface SidebarProps {
  playlists?: Playlist[]
  onCreatePlaylist?: () => void
}

const mainLinks = [
  { href: '/', label: 'Home', icon: Home },
  { href: '/search', label: 'Search', icon: Search },
  { href: '/library', label: 'Your Library', icon: Library },
]

export function Sidebar({ playlists = [], onCreatePlaylist }: SidebarProps) {
  const pathname = usePathname()

  return (
    <aside className="flex flex-col w-60 bg-black h-full flex-shrink-0 select-none">
      {/* Logo */}
      <div className="px-6 pt-6 pb-4">
        <Link href="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 bg-[#1DB954] rounded-full flex items-center justify-center flex-shrink-0">
            <Music2 size={16} className="text-black" />
          </div>
          <span className="text-white font-black text-xl tracking-tight group-hover:text-[#1DB954] transition-colors">
            Sportify
          </span>
        </Link>
      </div>

      {/* Main Nav */}
      <nav className="px-3 space-y-1">
        {mainLinks.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={cn(
              'flex items-center gap-4 px-3 py-2.5 rounded-md text-sm font-semibold transition-all duration-150',
              pathname === href
                ? 'text-white bg-[#282828]'
                : 'text-[#b3b3b3] hover:text-white hover:bg-[#1a1a1a]'
            )}
          >
            <Icon size={20} className="flex-shrink-0" />
            {label}
          </Link>
        ))}
      </nav>

      <div className="mx-3 my-3 h-px bg-[#282828]" />

      {/* Library section */}
      <div className="px-3 flex-1 overflow-hidden flex flex-col min-h-0">
        <div className="flex items-center justify-between px-3 mb-2">
          <span className="text-xs font-bold text-[#727272] uppercase tracking-widest">
            Playlists
          </span>
          <button
            onClick={onCreatePlaylist}
            className="text-[#b3b3b3] hover:text-white transition-colors p-1 rounded"
            title="Create playlist"
          >
            <PlusSquare size={18} />
          </button>
        </div>

        {/* Liked Songs shortcut */}
        <Link
          href="/library"
          className={cn(
            'flex items-center gap-3 px-3 py-2 rounded text-sm transition-colors mb-1',
            pathname === '/library' ? 'text-white' : 'text-[#b3b3b3] hover:text-white'
          )}
        >
          <div className="w-6 h-6 bg-gradient-to-br from-indigo-600 to-white rounded-sm flex items-center justify-center flex-shrink-0">
            <Heart size={12} className="text-white fill-white" />
          </div>
          <span className="font-semibold truncate">Liked Songs</span>
        </Link>

        {/* User playlists */}
        <div className="overflow-y-auto flex-1 space-y-0.5 scrollbar-thin scrollbar-thumb-[#535353]">
          {playlists.map((playlist) => (
            <Link
              key={playlist.id}
              href={`/playlist/${playlist.id}`}
              className={cn(
                'block px-3 py-2 text-sm rounded transition-colors truncate',
                pathname === `/playlist/${playlist.id}`
                  ? 'text-white'
                  : 'text-[#b3b3b3] hover:text-white'
              )}
            >
              {playlist.name}
            </Link>
          ))}
          {playlists.length === 0 && (
            <p className="px-3 py-2 text-xs text-[#535353]">
              Create your first playlist
            </p>
          )}
        </div>
      </div>
    </aside>
  )
}
