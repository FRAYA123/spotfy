'use client'

import { Search, X } from 'lucide-react'
import { cn } from '@/lib/utils'

interface SearchBarProps {
  value: string
  onChange: (val: string) => void
  placeholder?: string
  className?: string
  autoFocus?: boolean
}

export function SearchBar({
  value, onChange, placeholder = 'What do you want to listen to?',
  className, autoFocus = false
}: SearchBarProps) {
  return (
    <div className={cn('relative', className)}>
      <Search
        size={16}
        className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#121212] pointer-events-none"
      />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        autoFocus={autoFocus}
        className={cn(
          'w-full bg-white text-[#121212] placeholder-[#535353]',
          'rounded-full pl-10 pr-10 py-3 text-sm font-medium',
          'outline-none focus:ring-2 focus:ring-white',
          'transition-all duration-200'
        )}
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#121212] hover:opacity-70"
        >
          <X size={16} />
        </button>
      )}
    </div>
  )
}
