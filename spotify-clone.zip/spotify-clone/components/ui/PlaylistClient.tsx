'use client'

import { useRef, useState, useEffect } from 'react'
import { Music2, Play, Clock } from 'lucide-react'
import { Header } from '@/components/layout/Header'
import { SongCard } from '@/components/ui/SongCard'
import { usePlayerStore } from '@/store/usePlayerStore'
import { Playlist, Song } from '@/types'
import { formatTime } from '@/lib/utils'

interface PlaylistClientProps {
  playlist: Playlist
  songs: Song[]
  userId?: string
}

export function PlaylistClient({ playlist, songs, userId }: PlaylistClientProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [scrolled, setScrolled] = useState(false)
  const { playSong } = usePlayerStore()

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const handler = () => setScrolled(el.scrollTop > 200)
    el.addEventListener('scroll', handler, { passive: true })
    return () => el.removeEventListener('scroll', handler)
  }, [])

  const totalDuration = songs.reduce((acc, s) => acc + s.duration, 0)

  return (
    <div ref={scrollRef} className="h-full overflow-y-auto">
      {/* Hero */}
      <div className="relative">
        <div className="absolute inset-0 bg-gradient-to-b from-indigo-700/80 to-[#121212] pointer-events-none" />
        <Header scrolled={scrolled} bgColor="#312e81" />

        <div className="relative flex items-end gap-6 px-6 pt-4 pb-8">
          <div className="w-44 h-44 md:w-56 md:h-56 bg-gradient-to-br from-indigo-500 to-purple-700 rounded-md shadow-2xl flex items-center justify-center flex-shrink-0">
            {playlist.cover_url ? (
              <img src={playlist.cover_url} alt={playlist.name} className="w-full h-full object-cover rounded-md" />
            ) : (
              <Music2 size={64} className="text-white/60" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white uppercase tracking-wider mb-2">Playlist</p>
            <h1 className="text-4xl md:text-6xl font-black text-white mb-4 truncate">{playlist.name}</h1>
            {playlist.description && (
              <p className="text-[#b3b3b3] text-sm mb-3">{playlist.description}</p>
            )}
            <p className="text-[#b3b3b3] text-sm">
              {songs.length} songs
              {totalDuration > 0 && (
                <span>, about {Math.round(totalDuration / 60)} min</span>
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="bg-gradient-to-b from-[#121212]/80 to-[#121212] px-6 pt-4 pb-2">
        <div className="flex items-center gap-4 mb-6">
          <button
            onClick={() => songs[0] && playSong(songs[0], songs)}
            disabled={songs.length === 0}
            className="w-14 h-14 bg-[#1DB954] hover:bg-[#1ed760] disabled:opacity-40 rounded-full flex items-center justify-center shadow-lg hover:scale-105 transition-transform"
          >
            <Play size={24} fill="#000" color="#000" className="ml-1" />
          </button>
        </div>

        {/* Table header */}
        {songs.length > 0 && (
          <div className="grid grid-cols-[2rem_1fr_1fr_4rem] gap-4 px-4 pb-2 border-b border-[#282828] text-xs text-[#b3b3b3] uppercase tracking-wider font-semibold mb-1">
            <span>#</span>
            <span>Title</span>
            <span className="hidden md:block">Album</span>
            <span className="flex items-center justify-end"><Clock size={14} /></span>
          </div>
        )}

        {/* Song list */}
        {songs.length === 0 ? (
          <div className="text-center py-16">
            <p className="text-[#b3b3b3]">This playlist is empty.</p>
            <p className="text-[#535353] text-sm mt-2">Search for songs and add them here.</p>
          </div>
        ) : (
          <div className="space-y-0 pb-8">
            {songs.map((song, i) => (
              <SongCard
                key={song.id}
                song={song}
                queue={songs}
                variant="row"
                index={i + 1}
                showAlbum
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
