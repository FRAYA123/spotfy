'use client'

import { useRef, useState, useEffect } from 'react'
import { Heart, Music2, PlusCircle } from 'lucide-react'
import { Header } from '@/components/layout/Header'
import { SongCard } from '@/components/ui/SongCard'
import { createPlaylist } from '@/lib/queries'
import { Song, Playlist } from '@/types'
import { usePlayerStore } from '@/store/usePlayerStore'
import { useRouter } from 'next/navigation'

interface LibraryClientProps {
  likedSongs: Song[]
  playlists: Playlist[]
  userId: string
}

export function LibraryClient({ likedSongs, playlists, userId }: LibraryClientProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [scrolled, setScrolled] = useState(false)
  const [activeTab, setActiveTab] = useState<'liked' | 'playlists'>('liked')
  const [creating, setCreating] = useState(false)
  const { playSong } = usePlayerStore()
  const router = useRouter()

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const handler = () => setScrolled(el.scrollTop > 64)
    el.addEventListener('scroll', handler, { passive: true })
    return () => el.removeEventListener('scroll', handler)
  }, [])

  async function handleCreatePlaylist() {
    const name = prompt('Playlist name:')
    if (!name?.trim()) return
    setCreating(true)
    try {
      const playlist = await createPlaylist(userId, name.trim())
      if (playlist) router.push(`/playlist/${playlist.id}`)
    } finally {
      setCreating(false)
      router.refresh()
    }
  }

  return (
    <div ref={scrollRef} className="h-full overflow-y-auto">
      {/* Hero gradient */}
      <div className="absolute top-0 left-0 right-0 h-64 bg-gradient-to-b from-indigo-800/50 to-transparent pointer-events-none" />

      <Header scrolled={scrolled} />

      <div className="relative px-6 pb-8">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-black text-white">Your Library</h1>
          <button
            onClick={handleCreatePlaylist}
            disabled={creating}
            className="flex items-center gap-2 text-[#b3b3b3] hover:text-white transition-colors text-sm font-semibold"
          >
            <PlusCircle size={20} />
            New Playlist
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          {(['liked', 'playlists'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-colors ${
                activeTab === tab
                  ? 'bg-white text-black'
                  : 'bg-[#282828] text-white hover:bg-[#3e3e3e]'
              }`}
            >
              {tab === 'liked' ? 'Liked Songs' : 'Playlists'}
            </button>
          ))}
        </div>

        {/* Liked Songs tab */}
        {activeTab === 'liked' && (
          <div>
            {likedSongs.length === 0 ? (
              <div className="text-center py-16">
                <Heart size={48} className="text-[#535353] mx-auto mb-4" />
                <p className="text-white font-bold text-lg mb-2">Songs you like will appear here</p>
                <p className="text-[#b3b3b3] text-sm">Save songs by tapping the heart icon.</p>
              </div>
            ) : (
              <>
                {/* Play all button */}
                <button
                  onClick={() => likedSongs[0] && playSong(likedSongs[0], likedSongs)}
                  className="w-14 h-14 bg-[#1DB954] hover:bg-[#1ed760] rounded-full flex items-center justify-center mb-6 shadow-lg hover:scale-105 transition-transform"
                >
                  <svg viewBox="0 0 24 24" fill="#000" width="24" height="24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </button>

                {/* Song list header */}
                <div className="grid grid-cols-[2rem_1fr_1fr_4rem] gap-4 px-4 pb-2 border-b border-[#282828] text-xs text-[#b3b3b3] uppercase tracking-wider font-semibold mb-1">
                  <span>#</span>
                  <span>Title</span>
                  <span className="hidden md:block">Album</span>
                  <span className="text-right">⏱</span>
                </div>

                <div className="space-y-0">
                  {likedSongs.map((song, i) => (
                    <SongCard
                      key={song.id}
                      song={song}
                      queue={likedSongs}
                      variant="row"
                      index={i + 1}
                      showAlbum
                      isLiked
                    />
                  ))}
                </div>
              </>
            )}
          </div>
        )}

        {/* Playlists tab */}
        {activeTab === 'playlists' && (
          <div>
            {playlists.length === 0 ? (
              <div className="text-center py-16">
                <Music2 size={48} className="text-[#535353] mx-auto mb-4" />
                <p className="text-white font-bold text-lg mb-2">Create your first playlist</p>
                <p className="text-[#b3b3b3] text-sm mb-6">It's easy, we'll help you.</p>
                <button
                  onClick={handleCreatePlaylist}
                  className="bg-white text-black font-bold text-sm px-6 py-3 rounded-full hover:scale-105 transition-transform"
                >
                  Create playlist
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                {playlists.map(playlist => (
                  <a key={playlist.id} href={`/playlist/${playlist.id}`}>
                    <div className="bg-[#181818] hover:bg-[#282828] rounded-lg p-4 transition-colors cursor-pointer group">
                      <div className="aspect-square bg-gradient-to-br from-indigo-600 to-purple-700 rounded-md mb-3 flex items-center justify-center">
                        <Music2 size={28} className="text-white/70" />
                      </div>
                      <p className="text-white font-bold text-sm truncate">{playlist.name}</p>
                      <p className="text-[#b3b3b3] text-xs mt-1">Playlist</p>
                    </div>
                  </a>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
