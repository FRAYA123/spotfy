'use client'

import { useRef, useState, useEffect } from 'react'
import { Play, Clock, Disc3 } from 'lucide-react'
import { Header } from '@/components/layout/Header'
import { SongCard } from '@/components/ui/SongCard'
import { usePlayerStore } from '@/store/usePlayerStore'
import { Album, Song } from '@/types'
import { randomGradient } from '@/lib/utils'

interface AlbumClientProps {
  album: Album & { artists?: { name: string; id: string } }
  songs: Song[]
}

export function AlbumClient({ album, songs }: AlbumClientProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [scrolled, setScrolled] = useState(false)
  const { playSong } = usePlayerStore()
  const gradient = randomGradient(album.id)

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const handler = () => setScrolled(el.scrollTop > 200)
    el.addEventListener('scroll', handler, { passive: true })
    return () => el.removeEventListener('scroll', handler)
  }, [])

  return (
    <div ref={scrollRef} className="h-full overflow-y-auto">
      <div className="relative">
        <div className={`absolute inset-0 bg-gradient-to-b ${gradient} opacity-70 pointer-events-none`} />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-[#121212] pointer-events-none" />
        <Header scrolled={scrolled} />

        <div className="relative flex items-end gap-6 px-6 pt-4 pb-8">
          <div className="w-44 h-44 md:w-56 md:h-56 shadow-2xl rounded-md overflow-hidden flex-shrink-0">
            {album.cover_url ? (
              <img src={album.cover_url} alt={album.title} className="w-full h-full object-cover" />
            ) : (
              <div className={`w-full h-full bg-gradient-to-br ${gradient} flex items-center justify-center`}>
                <Disc3 size={64} className="text-white/40" />
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold text-white uppercase tracking-wider mb-2">Album</p>
            <h1 className="text-4xl md:text-5xl font-black text-white mb-4 truncate">{album.title}</h1>
            <p className="text-white text-sm font-semibold">
              {album.artists?.name && (
                <a href={`/artist/${(album as any).artist_id}`} className="hover:underline">
                  {album.artists.name}
                </a>
              )}
              {album.release_year && <span className="text-[#b3b3b3]"> · {album.release_year}</span>}
              <span className="text-[#b3b3b3]"> · {songs.length} songs</span>
            </p>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-b from-[#121212]/60 to-[#121212] px-6 pt-4">
        <button
          onClick={() => songs[0] && playSong(songs[0], songs)}
          disabled={songs.length === 0}
          className="w-14 h-14 bg-[#1DB954] hover:bg-[#1ed760] rounded-full flex items-center justify-center shadow-lg hover:scale-105 transition-transform mb-6"
        >
          <Play size={24} fill="#000" color="#000" className="ml-1" />
        </button>

        {songs.length > 0 && (
          <div className="grid grid-cols-[2rem_1fr_4rem] gap-4 px-4 pb-2 border-b border-[#282828] text-xs text-[#b3b3b3] uppercase tracking-wider font-semibold mb-1">
            <span>#</span>
            <span>Title</span>
            <span className="flex items-center justify-end"><Clock size={14} /></span>
          </div>
        )}

        <div className="space-y-0 pb-8">
          {songs.map((song, i) => (
            <SongCard
              key={song.id}
              song={song}
              queue={songs}
              variant="row"
              index={i + 1}
              showAlbum={false}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
