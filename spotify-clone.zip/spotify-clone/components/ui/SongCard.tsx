'use client'

import Image from 'next/image'
import { Play, Pause, MoreHorizontal, Mic2, Heart } from 'lucide-react'
import { usePlayerStore } from '@/store/usePlayerStore'
import { Song } from '@/types'
import { cn } from '@/lib/utils'
import { formatTime } from '@/lib/utils'

interface SongCardProps {
  song: Song
  queue?: Song[]
  variant?: 'card' | 'row'
  index?: number
  showAlbum?: boolean
  onLike?: (id: string) => void
  isLiked?: boolean
}

export function SongCard({
  song, queue, variant = 'card', index,
  showAlbum = true, onLike, isLiked = false
}: SongCardProps) {
  const { currentSong, isPlaying, playSong, togglePlay } = usePlayerStore()
  const isActive = currentSong?.id === song.id

  function handlePlay(e: React.MouseEvent) {
    e.preventDefault()
    if (isActive) {
      togglePlay()
    } else {
      playSong(song, queue || [song])
    }
  }

  const cover = song.cover_url || song.albums?.cover_url

  if (variant === 'row') {
    return (
      <div
        className={cn(
          'group flex items-center gap-4 px-4 py-2 rounded-md hover:bg-white/5 transition-colors cursor-pointer',
          isActive && 'bg-white/10'
        )}
        onDoubleClick={handlePlay}
      >
        {/* Index / play indicator */}
        <div className="w-8 flex items-center justify-center flex-shrink-0">
          {isActive ? (
            <span className="text-[#1DB954] text-xs font-bold">♪</span>
          ) : (
            <>
              <span className={cn('text-[#b3b3b3] text-sm tabular-nums group-hover:hidden', isActive && 'hidden')}>
                {index ?? ''}
              </span>
              <button
                onClick={handlePlay}
                className="hidden group-hover:flex items-center justify-center text-white"
              >
                {isActive && isPlaying ? <Pause size={14} fill="currentColor" /> : <Play size={14} fill="currentColor" />}
              </button>
            </>
          )}
        </div>

        {/* Cover + title */}
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className="w-10 h-10 relative rounded flex-shrink-0 bg-[#282828] overflow-hidden">
            {cover
              ? <Image src={cover} alt={song.title} fill className="object-cover" />
              : <div className="w-full h-full flex items-center justify-center"><Mic2 size={16} className="text-[#535353]" /></div>
            }
          </div>
          <div className="min-w-0">
            <p className={cn('text-sm font-medium truncate', isActive ? 'text-[#1DB954]' : 'text-white')}>
              {song.title}
              {song.is_explicit && (
                <span className="ml-2 text-[10px] bg-[#535353] text-white px-1 py-0.5 rounded align-middle">E</span>
              )}
            </p>
            <p className="text-xs text-[#b3b3b3] truncate hover:text-white hover:underline cursor-pointer transition-colors">
              {song.artists?.name || 'Unknown'}
            </p>
          </div>
        </div>

        {/* Album */}
        {showAlbum && (
          <p className="text-xs text-[#b3b3b3] truncate hidden md:block w-40 hover:text-white hover:underline cursor-pointer transition-colors">
            {song.albums?.title || '—'}
          </p>
        )}

        {/* Like + duration */}
        <div className="flex items-center gap-4 flex-shrink-0">
          {onLike && (
            <button
              onClick={(e) => { e.stopPropagation(); onLike(song.id) }}
              className={cn(
                'opacity-0 group-hover:opacity-100 transition-opacity',
                isLiked ? 'text-[#1DB954] opacity-100' : 'text-[#b3b3b3] hover:text-white'
              )}
            >
              <Heart size={16} fill={isLiked ? 'currentColor' : 'none'} />
            </button>
          )}
          <span className="text-xs text-[#b3b3b3] tabular-nums">{formatTime(song.duration)}</span>
          <button className="text-[#b3b3b3] hover:text-white opacity-0 group-hover:opacity-100 transition-all">
            <MoreHorizontal size={16} />
          </button>
        </div>
      </div>
    )
  }

  // Card variant
  return (
    <div className="group bg-[#181818] hover:bg-[#282828] rounded-lg p-4 cursor-pointer transition-colors duration-200 relative">
      {/* Cover image */}
      <div className="relative aspect-square rounded-md overflow-hidden bg-[#333] mb-3">
        {cover ? (
          <Image src={cover} alt={song.title} fill className="object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Mic2 size={32} className="text-[#535353]" />
          </div>
        )}
        {/* Hover play button */}
        <button
          onClick={handlePlay}
          className={cn(
            'absolute bottom-2 right-2 w-10 h-10 bg-[#1DB954] hover:bg-[#1ed760] rounded-full flex items-center justify-center',
            'shadow-[0_8px_16px_rgba(0,0,0,0.5)] transition-all duration-200',
            'opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0',
            isActive && 'opacity-100 translate-y-0'
          )}
        >
          {isActive && isPlaying
            ? <Pause size={18} fill="#000" color="#000" />
            : <Play size={18} fill="#000" color="#000" className="ml-0.5" />
          }
        </button>
      </div>

      {/* Info */}
      <p className={cn('text-sm font-bold truncate mb-1', isActive ? 'text-[#1DB954]' : 'text-white')}>
        {song.title}
      </p>
      <p className="text-xs text-[#b3b3b3] truncate">
        {song.artists?.name || 'Unknown Artist'}
      </p>
    </div>
  )
}
