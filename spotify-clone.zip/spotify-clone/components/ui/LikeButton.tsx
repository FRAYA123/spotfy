'use client'

import { Heart } from 'lucide-react'
import { useState, useCallback } from 'react'
import { toggleLike } from '@/lib/queries'
import { cn } from '@/lib/utils'

interface LikeButtonProps {
  songId: string
  userId?: string
  initialLiked?: boolean
  size?: number
  className?: string
}

export function LikeButton({ songId, userId, initialLiked = false, size = 16, className }: LikeButtonProps) {
  const [liked, setLiked] = useState(initialLiked)
  const [loading, setLoading] = useState(false)

  const handleToggle = useCallback(async (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (!userId || loading) return

    setLiked(prev => !prev) // Optimistic UI
    setLoading(true)
    try {
      const result = await toggleLike(userId, songId)
      setLiked(result)
    } catch {
      setLiked(prev => !prev) // Revert on error
    } finally {
      setLoading(false)
    }
  }, [userId, songId, loading])

  return (
    <button
      onClick={handleToggle}
      disabled={!userId || loading}
      className={cn(
        'transition-all duration-150 active:scale-90',
        liked ? 'text-[#1DB954]' : 'text-[#b3b3b3] hover:text-white',
        !userId && 'opacity-40 cursor-not-allowed',
        className
      )}
      title={liked ? 'Remove from Liked Songs' : 'Save to Liked Songs'}
    >
      <Heart size={size} fill={liked ? 'currentColor' : 'none'} />
    </button>
  )
}
