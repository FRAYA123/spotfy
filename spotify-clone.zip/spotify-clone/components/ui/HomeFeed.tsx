'use client'

import { useRef, useState, useEffect } from 'react'
import { Header } from '@/components/layout/Header'
import { SongCard } from '@/components/ui/SongCard'
import { AlbumCard } from '@/components/ui/AlbumCard'
import { ArtistCard } from '@/components/ui/ArtistCard'
import { Song, Album, Artist, User } from '@/types'

interface HomeFeedProps {
  greeting: string
  songs: Song[]
  albums: Album[]
  artists: Artist[]
  user: User | null
}

export function HomeFeed({ greeting, songs, albums, artists, user }: HomeFeedProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const handler = () => setScrolled(el.scrollTop > 64)
    el.addEventListener('scroll', handler, { passive: true })
    return () => el.removeEventListener('scroll', handler)
  }, [])

  return (
    <div ref={scrollRef} className="h-full overflow-y-auto relative">
      {/* Gradient hero */}
      <div className="absolute top-0 left-0 right-0 h-80 bg-gradient-to-b from-emerald-800/60 to-transparent pointer-events-none" />

      <Header scrolled={scrolled} user={user} />

      <div className="relative px-6 pb-8">
        {/* Greeting */}
        <h1 className="text-3xl font-black text-white mb-6">{greeting}</h1>

        {/* Quick picks grid */}
        {songs.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-8">
            {songs.slice(0, 6).map(song => (
              <button
                key={song.id}
                className="flex items-center gap-3 bg-white/10 hover:bg-white/20 rounded-md overflow-hidden text-left transition-colors group"
                onClick={() => {}}
              >
                <div
                  className="w-12 h-12 flex-shrink-0 bg-cover bg-center"
                  style={song.cover_url ? { backgroundImage: `url(${song.cover_url})` } : {}}
                />
                <span className="text-white text-sm font-bold truncate pr-3">{song.title}</span>
              </button>
            ))}
          </div>
        )}

        {/* Songs section */}
        {songs.length > 0 && (
          <section className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-black text-white hover:underline cursor-pointer">
                New releases
              </h2>
              <a href="/search" className="text-xs font-bold text-[#b3b3b3] hover:text-white uppercase tracking-wider transition-colors">
                See all
              </a>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {songs.slice(0, 6).map(song => (
                <SongCard key={song.id} song={song} queue={songs} variant="card" />
              ))}
            </div>
          </section>
        )}

        {/* Albums section */}
        {albums.length > 0 && (
          <section className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-black text-white hover:underline cursor-pointer">
                Popular albums
              </h2>
              <a href="/albums" className="text-xs font-bold text-[#b3b3b3] hover:text-white uppercase tracking-wider transition-colors">
                See all
              </a>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {albums.slice(0, 6).map(album => (
                <AlbumCard key={album.id} album={album} />
              ))}
            </div>
          </section>
        )}

        {/* Artists section */}
        {artists.length > 0 && (
          <section className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-black text-white hover:underline cursor-pointer">
                Popular artists
              </h2>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
              {artists.slice(0, 6).map(artist => (
                <ArtistCard key={artist.id} artist={artist} />
              ))}
            </div>
          </section>
        )}

        {/* Empty state */}
        {songs.length === 0 && albums.length === 0 && (
          <div className="text-center py-20">
            <p className="text-[#b3b3b3] text-lg mb-2">No music yet</p>
            <p className="text-[#535353] text-sm">Upload some songs to get started</p>
          </div>
        )}
      </div>
    </div>
  )
}
