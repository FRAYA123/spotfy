'use client'

import Image from 'next/image'
import Link from 'next/link'
import { UserCircle2, BadgeCheck } from 'lucide-react'
import { Artist } from '@/types'

interface ArtistCardProps {
  artist: Artist
}

export function ArtistCard({ artist }: ArtistCardProps) {
  return (
    <Link href={`/artist/${artist.id}`}>
      <div className="group bg-[#181818] hover:bg-[#282828] rounded-lg p-4 cursor-pointer transition-colors duration-200">
        <div className="relative aspect-square rounded-full overflow-hidden bg-[#333] mb-4 shadow-lg mx-auto">
          {artist.image_url ? (
            <Image src={artist.image_url} alt={artist.name} fill className="object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <UserCircle2 size={48} className="text-[#535353]" />
            </div>
          )}
        </div>
        <div className="flex items-center gap-1.5 mb-1">
          <p className="text-white text-sm font-bold truncate">{artist.name}</p>
          {artist.verified && (
            <BadgeCheck size={14} className="text-[#3D91F4] flex-shrink-0" />
          )}
        </div>
        <p className="text-[#b3b3b3] text-xs truncate">Artist</p>
      </div>
    </Link>
  )
}
