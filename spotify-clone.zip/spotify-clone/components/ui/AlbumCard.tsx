'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Play, Disc3 } from 'lucide-react'
import { Album } from '@/types'
import { cn } from '@/lib/utils'

interface AlbumCardProps {
  album: Album
}

export function AlbumCard({ album }: AlbumCardProps) {
  return (
    <Link href={`/album/${album.id}`}>
      <div className="group bg-[#181818] hover:bg-[#282828] rounded-lg p-4 cursor-pointer transition-colors duration-200">
        <div className="relative aspect-square rounded-md overflow-hidden bg-[#333] mb-3 shadow-lg">
          {album.cover_url ? (
            <Image src={album.cover_url} alt={album.title} fill className="object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center">
              <Disc3 size={36} className="text-[#535353]" />
            </div>
          )}
          <button className={cn(
            'absolute bottom-2 right-2 w-10 h-10 bg-[#1DB954] hover:bg-[#1ed760] rounded-full flex items-center justify-center',
            'shadow-[0_8px_16px_rgba(0,0,0,0.5)] transition-all duration-200',
            'opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0'
          )}>
            <Play size={18} fill="#000" color="#000" className="ml-0.5" />
          </button>
        </div>
        <p className="text-white text-sm font-bold truncate mb-1">{album.title}</p>
        <p className="text-[#b3b3b3] text-xs truncate">
          {album.release_year && `${album.release_year} • `}
          {(album as any).artists?.name || 'Album'}
        </p>
      </div>
    </Link>
  )
}
