import { cn } from '@/lib/utils'

export function Skeleton({ className }: { className?: string }) {
  return (
    <div className={cn('animate-pulse bg-[#282828] rounded-md', className)} />
  )
}

export function SongCardSkeleton() {
  return (
    <div className="bg-[#181818] rounded-lg p-4">
      <Skeleton className="aspect-square rounded-md mb-3" />
      <Skeleton className="h-3.5 w-3/4 mb-2" />
      <Skeleton className="h-3 w-1/2" />
    </div>
  )
}

export function SongRowSkeleton() {
  return (
    <div className="flex items-center gap-4 px-4 py-2">
      <Skeleton className="w-8 h-4" />
      <Skeleton className="w-10 h-10 rounded flex-shrink-0" />
      <div className="flex-1 space-y-1.5">
        <Skeleton className="h-3.5 w-48" />
        <Skeleton className="h-3 w-32" />
      </div>
      <Skeleton className="h-3 w-12 hidden md:block" />
      <Skeleton className="h-3 w-10" />
    </div>
  )
}

export function GridSkeleton({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <SongCardSkeleton key={i} />
      ))}
    </div>
  )
}
