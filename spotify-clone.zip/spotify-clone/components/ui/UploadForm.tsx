'use client'

import { useState, useRef } from 'react'
import { Upload, Music2, Image, Loader2, CheckCircle2, X } from 'lucide-react'
import { cn } from '@/lib/utils'

interface UploadFormProps {
  onSuccess?: () => void
}

export function UploadForm({ onSuccess }: UploadFormProps) {
  const [title, setTitle] = useState('')
  const [audioFile, setAudioFile] = useState<File | null>(null)
  const [coverFile, setCoverFile] = useState<File | null>(null)
  const [coverPreview, setCoverPreview] = useState<string | null>(null)
  const [duration, setDuration] = useState(0)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')
  const audioRef = useRef<HTMLAudioElement>(null)

  function handleAudioChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setAudioFile(file)
    // Auto-fill title from filename
    if (!title) {
      setTitle(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '))
    }
    // Get duration
    const url = URL.createObjectURL(file)
    const audio = new Audio(url)
    audio.addEventListener('loadedmetadata', () => {
      setDuration(Math.round(audio.duration))
      URL.revokeObjectURL(url)
    })
  }

  function handleCoverChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setCoverFile(file)
    const url = URL.createObjectURL(file)
    setCoverPreview(url)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!audioFile || !title.trim()) return

    setLoading(true)
    setError('')

    try {
      const formData = new FormData()
      formData.append('title', title.trim())
      formData.append('audio', audioFile)
      formData.append('duration', String(duration))
      if (coverFile) formData.append('cover', coverFile)

      const res = await fetch('/api/upload', { method: 'POST', body: formData })
      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'Upload failed')
      }

      setSuccess(true)
      setTimeout(() => {
        setTitle('')
        setAudioFile(null)
        setCoverFile(null)
        setCoverPreview(null)
        setDuration(0)
        setSuccess(false)
        onSuccess?.()
      }, 2000)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <div className="flex flex-col items-center justify-center py-12 gap-3">
        <CheckCircle2 size={48} className="text-[#1DB954]" />
        <p className="text-white font-bold text-lg">Upload successful!</p>
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Cover image */}
      <div className="flex items-start gap-5">
        <label className="cursor-pointer flex-shrink-0">
          <div className={cn(
            'w-32 h-32 rounded-md border-2 border-dashed flex flex-col items-center justify-center gap-2 transition-colors',
            coverPreview ? 'border-transparent overflow-hidden' : 'border-[#535353] hover:border-[#b3b3b3]'
          )}>
            {coverPreview ? (
              <img src={coverPreview} alt="Cover" className="w-full h-full object-cover" />
            ) : (
              <>
                <Image size={28} className="text-[#535353]" />
                <span className="text-xs text-[#727272] text-center">Cover Art</span>
              </>
            )}
          </div>
          <input type="file" accept="image/*" className="hidden" onChange={handleCoverChange} />
        </label>

        <div className="flex-1 space-y-3">
          <div>
            <label className="block text-xs font-bold text-[#b3b3b3] uppercase tracking-wider mb-1.5">
              Song title *
            </label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              required
              placeholder="Enter song title"
              className="w-full bg-[#3e3e3e] text-white placeholder-[#727272] rounded-md px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-[#1DB954]"
            />
          </div>

          {/* Audio file */}
          <div>
            <label className="block text-xs font-bold text-[#b3b3b3] uppercase tracking-wider mb-1.5">
              Audio file (MP3) *
            </label>
            <label className="cursor-pointer block">
              <div className={cn(
                'flex items-center gap-3 border border-dashed rounded-md px-4 py-2.5 transition-colors',
                audioFile ? 'border-[#1DB954] bg-[#1DB954]/10' : 'border-[#535353] hover:border-[#b3b3b3]'
              )}>
                <Music2 size={18} className={audioFile ? 'text-[#1DB954]' : 'text-[#535353]'} />
                <span className="text-sm truncate flex-1">
                  {audioFile
                    ? <span className="text-[#1DB954]">{audioFile.name}</span>
                    : <span className="text-[#727272]">Choose MP3 file...</span>
                  }
                </span>
                {audioFile && duration > 0 && (
                  <span className="text-xs text-[#b3b3b3] flex-shrink-0">
                    {Math.floor(duration / 60)}:{String(duration % 60).padStart(2, '0')}
                  </span>
                )}
              </div>
              <input type="file" accept="audio/mpeg,audio/mp3,.mp3" className="hidden" onChange={handleAudioChange} required />
            </label>
          </div>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-red-400 bg-red-400/10 rounded-md px-4 py-2.5 text-sm">
          <X size={16} className="flex-shrink-0" />
          {error}
        </div>
      )}

      <button
        type="submit"
        disabled={loading || !audioFile || !title.trim()}
        className={cn(
          'w-full flex items-center justify-center gap-2 py-3 rounded-full font-bold text-sm transition-all',
          loading || !audioFile || !title.trim()
            ? 'bg-[#535353] text-[#b3b3b3] cursor-not-allowed'
            : 'bg-[#1DB954] hover:bg-[#1ed760] text-black hover:scale-[1.02]'
        )}
      >
        {loading ? (
          <><Loader2 size={16} className="animate-spin" /> Uploading...</>
        ) : (
          <><Upload size={16} /> Upload Song</>
        )}
      </button>
    </form>
  )
}
