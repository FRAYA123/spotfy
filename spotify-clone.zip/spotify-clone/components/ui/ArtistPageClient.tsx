'use client'

import { useRef, useState, useEffect } from 'react'
import { Play, BadgeCheck, UserCircle2 } from 'lucide-react'
import { Header } from '@/components/layout/Header'
import { SongCard } from '@/components/ui/SongCard'
import { AlbumCard } from '@/components/ui/AlbumCard'
import { usePlayerStore } from '@/store/usePlayerStore'
import { Artist, Song, Album } from '@/types'
import { formatNumber } from '@/lib/utils'

interface ArtistPageClientProps {
  artist: Artist
  songs: Song[]
  albums: Album[]
}

export function ArtistPageClient({ artist, songs, albums }: ArtistPageClientProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [scrolled, setScrolled] = useState(false)
  const { playSong } = usePlayerStore()

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const handler = () => setScrolled(el.scrollTop > 240)
    el.addEventListener('scroll', handler, { passive: true })
    return () => el.removeEventListener('scroll', handler)
  }, [])

  return (
    <div ref={scrollRef} className="h-full overflow-y-auto">
      {/* Artist hero */}
      <div className="relative h-72 md:h-80 overflow-hidden">
        {artist.image_url ? (
          <img
            src={artist.image_url}
            alt={artist.name}
            className="w-full h-full object-cover object-top"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
            <UserCircle2 size={80} className="text-[#535353]" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[#121212] via-[#121212]/30 to-transparent" />
        <Header scrolled={scrolled} />

        <div className="absolute bottom-0 left-0 px-6 pb-6">
          {artist.verified && (
            <div className="flex items-center gap-1.5 mb-2">
              <BadgeCheck size={16} className="text-[#3D91F4]" fill="#3D91F4" />
              <span className="text-white text-xs font-bold">Verified Artist</span>
            </div>
          )}
          <h1 className="text-5xl md:text-7xl font-black text-white mb-2">{artist.name}</h1>
          {artist.monthly_listeners > 0 && (
            <p className="text-[#b3b3b3] text-sm">
              {formatNumber(artist.monthly_listeners)} monthly listeners
            </p>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="bg-gradient-to-b from-[#121212]/60 to-[#121212] px-6 pt-6 pb-8">
        {/* Play button */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => songs[0] && playSong(songs[0], songs)}
            disabled={songs.length === 0}
            className="w-14 h-14 bg-[#1DB954] hover:bg-[#1ed760] rounded-full flex items-center justify-center shadow-lg hover:scale-105 transition-transform"
          >
            <Play size={24} fill="#000" color="#000" className="ml-1" />
          </button>
        </div>

        {/* Popular songs */}
        {songs.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xl font-black text-white mb-4">Popular</h2>
            <div className="space-y-1">
              {songs.slice(0, 10).map((song, i) => (
                <SongCard
                  key={song.id}
                  song={song}
                  queue={songs}
                  variant="row"
                  index={i + 1}
                  showAlbum
                />
              ))}
            </div>
          </section>
        )}

        {/* Albums */}
        {albums.length > 0 && (
          <section className="mb-8">
            <h2 className="text-xl font-black text-white mb-4">Albums</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {albums.map((album) => (
                <AlbumCard key={album.id} album={album} />
              ))}
            </div>
          </section>
        )}

        {/* Bio */}
        {artist.bio && (
          <section>
            <h2 className="text-xl font-black text-white mb-4">About</h2>
            <div className="bg-[#181818] rounded-lg p-6">
              {artist.image_url && (
                <img
                  src={artist.image_url}
                  alt={artist.name}
                  className="w-full h-48 object-cover rounded-md mb-4"
                />
              )}
              <p className="text-[#b3b3b3] text-sm leading-relaxed">{artist.bio}</p>
              {artist.monthly_listeners > 0 && (
                <p className="text-white font-bold mt-4">
                  {formatNumber(artist.monthly_listeners)} <span className="text-[#b3b3b3] font-normal">monthly listeners</span>
                </p>
              )}
            </div>
          </section>
        )}
      </div>
    </div>
  )
}
