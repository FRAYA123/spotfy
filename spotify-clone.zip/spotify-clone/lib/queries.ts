import { createClient } from './supabase'
import { Song, Artist, Album, Playlist } from '@/types'

const SONG_SELECT = `
  *,
  artists(id, name, image_url, verified),
  albums(id, title, cover_url)
`

// ─── Songs ────────────────────────────────────────────────────────────────────

export async function getSongs(search?: string): Promise<Song[]> {
  const supabase = createClient()
  let query = supabase
    .from('songs')
    .select(SONG_SELECT)
    .order('created_at', { ascending: false })
    .limit(50)

  if (search && search.trim()) {
    query = query.or(`title.ilike.%${search}%,artists.name.ilike.%${search}%`)
  }

  const { data, error } = await query
  if (error) throw error
  return (data as Song[]) || []
}

export async function getSongById(id: string): Promise<Song | null> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('songs')
    .select(SONG_SELECT)
    .eq('id', id)
    .single()
  if (error) return null
  return data as Song
}

export async function incrementPlayCount(id: string) {
  const supabase = createClient()
  await supabase.rpc('increment_play_count', { song_id: id })
}

// ─── Artists ──────────────────────────────────────────────────────────────────

export async function getArtists(): Promise<Artist[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('artists')
    .select('*')
    .order('monthly_listeners', { ascending: false })
    .limit(20)
  if (error) throw error
  return data || []
}

export async function getArtistById(id: string) {
  const supabase = createClient()
  const { data: artist, error } = await supabase
    .from('artists')
    .select('*')
    .eq('id', id)
    .single()
  if (error) return null

  const { data: songs } = await supabase
    .from('songs')
    .select(SONG_SELECT)
    .eq('artist_id', id)
    .order('play_count', { ascending: false })

  const { data: albums } = await supabase
    .from('albums')
    .select('*')
    .eq('artist_id', id)
    .order('release_year', { ascending: false })

  return { artist, songs: (songs as Song[]) || [], albums: albums || [] }
}

// ─── Albums ───────────────────────────────────────────────────────────────────

export async function getAlbums(): Promise<Album[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('albums')
    .select('*, artists(id, name, image_url)')
    .order('created_at', { ascending: false })
    .limit(20)
  if (error) throw error
  return (data as Album[]) || []
}

export async function getAlbumById(id: string) {
  const supabase = createClient()
  const { data: album, error } = await supabase
    .from('albums')
    .select('*, artists(id, name, image_url)')
    .eq('id', id)
    .single()
  if (error) return null

  const { data: songs } = await supabase
    .from('songs')
    .select(SONG_SELECT)
    .eq('album_id', id)
    .order('track_number', { ascending: true })

  return { album, songs: (songs as Song[]) || [] }
}

// ─── Playlists ────────────────────────────────────────────────────────────────

export async function getUserPlaylists(userId: string): Promise<Playlist[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('playlists')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
  if (error) throw error
  return data || []
}

export async function getPlaylistById(id: string) {
  const supabase = createClient()
  const { data: playlist, error } = await supabase
    .from('playlists')
    .select('*')
    .eq('id', id)
    .single()
  if (error) return null

  const { data: playlistSongs } = await supabase
    .from('playlist_songs')
    .select(`position, songs(${SONG_SELECT.trim()})`)
    .eq('playlist_id', id)
    .order('position', { ascending: true })

  const songs = (playlistSongs || []).map((ps: any) => ps.songs as Song).filter(Boolean)
  return { playlist, songs }
}

export async function createPlaylist(userId: string, name: string): Promise<Playlist | null> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('playlists')
    .insert({ user_id: userId, name })
    .select()
    .single()
  if (error) throw error
  return data
}

export async function addSongToPlaylist(playlistId: string, songId: string, position: number) {
  const supabase = createClient()
  const { error } = await supabase
    .from('playlist_songs')
    .insert({ playlist_id: playlistId, song_id: songId, position })
  if (error) throw error
}

export async function removeSongFromPlaylist(playlistId: string, songId: string) {
  const supabase = createClient()
  const { error } = await supabase
    .from('playlist_songs')
    .delete()
    .eq('playlist_id', playlistId)
    .eq('song_id', songId)
  if (error) throw error
}

// ─── Liked Songs ──────────────────────────────────────────────────────────────

export async function getLikedSongs(userId: string): Promise<Song[]> {
  const supabase = createClient()
  const { data, error } = await supabase
    .from('liked_songs')
    .select(`songs(${SONG_SELECT.trim()})`)
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
  if (error) throw error
  return (data || []).map((item: any) => item.songs as Song).filter(Boolean)
}

export async function isLiked(userId: string, songId: string): Promise<boolean> {
  const supabase = createClient()
  const { data } = await supabase
    .from('liked_songs')
    .select('song_id')
    .eq('user_id', userId)
    .eq('song_id', songId)
    .single()
  return !!data
}

export async function toggleLike(userId: string, songId: string): Promise<boolean> {
  const supabase = createClient()
  const liked = await isLiked(userId, songId)
  if (liked) {
    await supabase.from('liked_songs').delete().eq('user_id', userId).eq('song_id', songId)
    return false
  } else {
    await supabase.from('liked_songs').insert({ user_id: userId, song_id: songId })
    return true
  }
}

// ─── Search ───────────────────────────────────────────────────────────────────

export async function searchAll(query: string) {
  const supabase = createClient()
  const q = `%${query}%`

  const [songsRes, artistsRes, albumsRes] = await Promise.all([
    supabase.from('songs').select(SONG_SELECT).ilike('title', q).limit(10),
    supabase.from('artists').select('*').ilike('name', q).limit(5),
    supabase.from('albums').select('*, artists(name)').ilike('title', q).limit(5),
  ])

  return {
    songs: (songsRes.data as Song[]) || [],
    artists: artistsRes.data || [],
    albums: (albumsRes.data as Album[]) || [],
  }
}
