import { createClient } from './supabase'

export interface SongUploadData {
  title: string
  artist_id?: string
  album_id?: string
  track_number?: number
  is_explicit?: boolean
  duration: number
}

export async function uploadSong(
  audioFile: File,
  coverFile: File | null,
  metadata: SongUploadData
) {
  const supabase = createClient()
  const timestamp = Date.now()
  const safeAudioName = `${timestamp}-${audioFile.name.replace(/\s+/g, '-')}`

  // 1. Upload audio file
  const { data: audioData, error: audioError } = await supabase.storage
    .from('songs')
    .upload(`audio/${safeAudioName}`, audioFile, {
      contentType: 'audio/mpeg',
      cacheControl: '3600',
    })
  if (audioError) throw new Error(`Audio upload failed: ${audioError.message}`)

  const { data: { publicUrl: audioUrl } } = supabase.storage
    .from('songs')
    .getPublicUrl(audioData.path)

  // 2. Upload cover image (optional)
  let coverUrl: string | undefined
  if (coverFile) {
    const safeCoverName = `${timestamp}-${coverFile.name.replace(/\s+/g, '-')}`
    const { data: coverData, error: coverError } = await supabase.storage
      .from('songs')
      .upload(`covers/${safeCoverName}`, coverFile, {
        contentType: coverFile.type,
        cacheControl: '3600',
      })
    if (!coverError && coverData) {
      const { data: { publicUrl } } = supabase.storage
        .from('songs')
        .getPublicUrl(coverData.path)
      coverUrl = publicUrl
    }
  }

  // 3. Insert song metadata into DB
  const { data, error } = await supabase
    .from('songs')
    .insert({
      ...metadata,
      audio_url: audioUrl,
      cover_url: coverUrl,
    })
    .select()
    .single()

  if (error) throw new Error(`DB insert failed: ${error.message}`)
  return data
}

export async function uploadArtistImage(artistId: string, file: File) {
  const supabase = createClient()
  const fileName = `artist-${artistId}-${Date.now()}.${file.name.split('.').pop()}`

  const { data, error } = await supabase.storage
    .from('artists')
    .upload(fileName, file, { contentType: file.type })

  if (error) throw error

  const { data: { publicUrl } } = supabase.storage.from('artists').getPublicUrl(data.path)

  await supabase.from('artists').update({ image_url: publicUrl }).eq('id', artistId)
  return publicUrl
}

export async function uploadPlaylistCover(playlistId: string, file: File) {
  const supabase = createClient()
  const fileName = `playlist-${playlistId}-${Date.now()}.${file.name.split('.').pop()}`

  const { data, error } = await supabase.storage
    .from('playlists')
    .upload(fileName, file, { contentType: file.type })

  if (error) throw error

  const { data: { publicUrl } } = supabase.storage.from('playlists').getPublicUrl(data.path)

  await supabase.from('playlists').update({ cover_url: publicUrl }).eq('id', playlistId)
  return publicUrl
}
