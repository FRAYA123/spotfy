import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatTime(seconds: number): string {
  if (!seconds || isNaN(seconds)) return '0:00'
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return n.toString()
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .slice(0, 2)
    .map(w => w[0]?.toUpperCase() || '')
    .join('')
}

export function randomGradient(seed: string): string {
  const gradients = [
    'from-purple-700 to-blue-500',
    'from-pink-600 to-orange-400',
    'from-green-600 to-teal-400',
    'from-indigo-600 to-purple-400',
    'from-red-600 to-pink-400',
    'from-yellow-500 to-orange-500',
    'from-cyan-500 to-blue-600',
    'from-emerald-500 to-green-700',
  ]
  const idx = seed.charCodeAt(0) % gradients.length
  return gradients[idx]
}
