'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Music2, Eye, EyeOff, Loader2 } from 'lucide-react'
import { createClient } from '@/lib/supabase'
import Link from 'next/link'

export default function SignupPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    const supabase = createClient()
    const { error: err } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: name }
      }
    })
    if (err) {
      setError(err.message)
      setLoading(false)
    } else {
      setSuccess(true)
    }
  }

  if (success) {
    return (
      <div className="min-h-screen bg-[#121212] flex flex-col items-center justify-center px-4">
        <div className="w-10 h-10 bg-[#1DB954] rounded-full flex items-center justify-center mb-6">
          <Music2 size={22} className="text-black" />
        </div>
        <h1 className="text-2xl font-black text-white mb-4">Check your email</h1>
        <p className="text-[#b3b3b3] text-sm text-center max-w-sm">
          We sent a confirmation link to <strong className="text-white">{email}</strong>.
          Please check your inbox to complete registration.
        </p>
        <Link href="/login" className="mt-6 text-[#1DB954] font-semibold hover:underline text-sm">
          Back to Login
        </Link>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#121212] flex flex-col items-center justify-center px-4 py-12">
      <div className="flex items-center gap-2 mb-8">
        <div className="w-10 h-10 bg-[#1DB954] rounded-full flex items-center justify-center">
          <Music2 size={22} className="text-black" />
        </div>
        <span className="text-white font-black text-2xl">Sportify</span>
      </div>

      <div className="w-full max-w-sm bg-[#282828] rounded-xl p-8">
        <h1 className="text-2xl font-black text-white text-center mb-6">
          Sign up for free
        </h1>

        <form onSubmit={handleSignup} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              What's your name?
            </label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              required
              placeholder="Enter your name"
              className="w-full bg-[#3e3e3e] text-white placeholder-[#727272] rounded-md px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-white border border-transparent focus:border-white transition-colors"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              What's your email?
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              placeholder="Enter your email address"
              className="w-full bg-[#3e3e3e] text-white placeholder-[#727272] rounded-md px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-white border border-transparent focus:border-white transition-colors"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              Create a password
            </label>
            <div className="relative">
              <input
                type={showPw ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                minLength={8}
                placeholder="At least 8 characters"
                className="w-full bg-[#3e3e3e] text-white placeholder-[#727272] rounded-md px-4 py-3 pr-10 text-sm outline-none focus:ring-2 focus:ring-white border border-transparent focus:border-white transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPw(!showPw)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#727272] hover:text-white transition-colors"
              >
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <p className="text-red-400 text-sm bg-red-400/10 rounded-md px-3 py-2">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#1DB954] hover:bg-[#1ed760] disabled:opacity-60 text-black font-bold text-sm py-3 rounded-full transition-colors flex items-center justify-center gap-2"
          >
            {loading && <Loader2 size={16} className="animate-spin" />}
            Create Account
          </button>
        </form>

        <div className="mt-6 text-center border-t border-[#3e3e3e] pt-6">
          <p className="text-[#b3b3b3] text-sm">
            Already have an account?{' '}
            <Link href="/login" className="text-white font-semibold hover:underline">
              Log in here
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
