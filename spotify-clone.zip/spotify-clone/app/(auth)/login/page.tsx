'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Music2, Eye, EyeOff, Loader2 } from 'lucide-react'
import { createClient } from '@/lib/supabase'
import Link from 'next/link'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    const supabase = createClient()
    const { error: err } = await supabase.auth.signInWithPassword({ email, password })
    if (err) {
      setError(err.message)
      setLoading(false)
    } else {
      router.push('/')
      router.refresh()
    }
  }

  return (
    <div className="min-h-screen bg-[#121212] flex flex-col items-center justify-center px-4 py-12">
      {/* Logo */}
      <div className="flex items-center gap-2 mb-8">
        <div className="w-10 h-10 bg-[#1DB954] rounded-full flex items-center justify-center">
          <Music2 size={22} className="text-black" />
        </div>
        <span className="text-white font-black text-2xl">Sportify</span>
      </div>

      <div className="w-full max-w-sm bg-[#282828] rounded-xl p-8">
        <h1 className="text-2xl font-black text-white text-center mb-6">Log in to Sportify</h1>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              Email address
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              placeholder="name@example.com"
              className="w-full bg-[#3e3e3e] text-white placeholder-[#727272] rounded-md px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-white border border-transparent focus:border-white transition-colors"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-white mb-2">
              Password
            </label>
            <div className="relative">
              <input
                type={showPw ? 'text' : 'password'}
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                placeholder="Password"
                className="w-full bg-[#3e3e3e] text-white placeholder-[#727272] rounded-md px-4 py-3 pr-10 text-sm outline-none focus:ring-2 focus:ring-white border border-transparent focus:border-white transition-colors"
              />
              <button
                type="button"
                onClick={() => setShowPw(!showPw)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#727272] hover:text-white transition-colors"
              >
                {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <p className="text-red-400 text-sm bg-red-400/10 rounded-md px-3 py-2">{error}</p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-[#1DB954] hover:bg-[#1ed760] disabled:opacity-60 text-black font-bold text-sm py-3 rounded-full transition-colors flex items-center justify-center gap-2"
          >
            {loading && <Loader2 size={16} className="animate-spin" />}
            Log In
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-[#b3b3b3] text-sm">
            Don't have an account?{' '}
            <Link href="/signup" className="text-white font-semibold hover:underline">
              Sign up for Sportify
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
