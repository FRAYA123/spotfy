import { createServerSupabaseClient } from '@/lib/supabase-server'
import { getSongs, getAlbums, getArtists } from '@/lib/queries'
import { Header } from '@/components/layout/Header'
import { SongCard } from '@/components/ui/SongCard'
import { AlbumCard } from '@/components/ui/AlbumCard'
import { ArtistCard } from '@/components/ui/ArtistCard'
import { HomeFeed } from '@/components/ui/HomeFeed'

export default async function HomePage() {
  const supabase = await createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()

  const [songs, albums, artists] = await Promise.all([
    getSongs().catch(() => []),
    getAlbums().catch(() => []),
    getArtists().catch(() => []),
  ])

  const hour = new Date().getHours()
  const greeting =
    hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'

  return (
    <HomeFeed
      greeting={greeting}
      songs={songs}
      albums={albums}
      artists={artists}
      user={user as any}
    />
  )
}
