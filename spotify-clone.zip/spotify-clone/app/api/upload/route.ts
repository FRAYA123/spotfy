import { NextRequest, NextResponse } from 'next/server'
import { createServerSupabaseClient } from '@/lib/supabase-server'

export async function POST(request: NextRequest) {
  const supabase = await createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const formData = await request.formData()
    const audioFile = formData.get('audio') as File
    const coverFile = formData.get('cover') as File | null
    const title = formData.get('title') as string
    const artistId = formData.get('artist_id') as string | null
    const albumId = formData.get('album_id') as string | null
    const duration = parseInt(formData.get('duration') as string || '0')

    if (!audioFile || !title) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const timestamp = Date.now()
    const safeAudioName = `${timestamp}-${audioFile.name.replace(/\s+/g, '-')}`

    // Upload audio
    const audioBuffer = await audioFile.arrayBuffer()
    const { data: audioData, error: audioError } = await supabase.storage
      .from('songs')
      .upload(`audio/${safeAudioName}`, audioBuffer, {
        contentType: 'audio/mpeg',
        cacheControl: '3600',
      })
    if (audioError) throw audioError

    const { data: { publicUrl: audioUrl } } = supabase.storage
      .from('songs')
      .getPublicUrl(audioData.path)

    // Upload cover (optional)
    let coverUrl: string | undefined
    if (coverFile) {
      const safeCoverName = `${timestamp}-${coverFile.name.replace(/\s+/g, '-')}`
      const coverBuffer = await coverFile.arrayBuffer()
      const { data: coverData } = await supabase.storage
        .from('songs')
        .upload(`covers/${safeCoverName}`, coverBuffer, { contentType: coverFile.type })
      if (coverData) {
        const { data: { publicUrl } } = supabase.storage.from('songs').getPublicUrl(coverData.path)
        coverUrl = publicUrl
      }
    }

    // Insert metadata
    const { data: song, error: dbError } = await supabase
      .from('songs')
      .insert({
        title,
        artist_id: artistId || null,
        album_id: albumId || null,
        duration,
        audio_url: audioUrl,
        cover_url: coverUrl,
      })
      .select()
      .single()

    if (dbError) throw dbError
    return NextResponse.json(song, { status: 201 })

  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
