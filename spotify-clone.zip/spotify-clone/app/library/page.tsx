import { createServerSupabaseClient } from '@/lib/supabase-server'
import { getLikedSongs, getUserPlaylists } from '@/lib/queries'
import { LibraryClient } from '@/components/ui/LibraryClient'
import { redirect } from 'next/navigation'

export default async function LibraryPage() {
  const supabase = await createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/login')

  const [likedSongs, playlists] = await Promise.all([
    getLikedSongs(user.id).catch(() => []),
    getUserPlaylists(user.id).catch(() => []),
  ])

  return (
    <LibraryClient
      likedSongs={likedSongs}
      playlists={playlists}
      userId={user.id}
    />
  )
}
