import { getAlbumById } from '@/lib/queries'
import { AlbumClient } from '@/components/ui/AlbumClient'
import { notFound } from 'next/navigation'

interface Props {
  params: { id: string }
}

export default async function AlbumPage({ params }: Props) {
  const result = await getAlbumById(params.id)
  if (!result) notFound()
  return <AlbumClient album={result.album as any} songs={result.songs} />
}
