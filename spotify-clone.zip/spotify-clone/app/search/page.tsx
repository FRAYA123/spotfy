'use client'

import { useRef, useState, useEffect } from 'react'
import { Header } from '@/components/layout/Header'
import { SearchBar } from '@/components/ui/SearchBar'
import { SongCard } from '@/components/ui/SongCard'
import { ArtistCard } from '@/components/ui/ArtistCard'
import { AlbumCard } from '@/components/ui/AlbumCard'
import { useSearch } from '@/hooks/useSearch'
import { Loader2 } from 'lucide-react'

const GENRE_TILES = [
  { label: 'Pop', color: 'from-pink-500 to-rose-600' },
  { label: 'Hip-Hop', color: 'from-orange-500 to-yellow-500' },
  { label: 'Rock', color: 'from-red-700 to-red-900' },
  { label: 'Electronic', color: 'from-blue-500 to-cyan-400' },
  { label: 'R&B', color: 'from-purple-600 to-violet-800' },
  { label: 'Jazz', color: 'from-amber-500 to-orange-700' },
  { label: 'Classical', color: 'from-teal-500 to-emerald-700' },
  { label: 'Indie', color: 'from-lime-500 to-green-700' },
  { label: 'Metal', color: 'from-gray-600 to-gray-900' },
  { label: 'Folk', color: 'from-yellow-700 to-amber-900' },
]

export default function SearchPage() {
  const scrollRef = useRef<HTMLDivElement>(null)
  const [scrolled, setScrolled] = useState(false)
  const { query, setQuery, results, isLoading } = useSearch()
  const hasResults = query.trim().length > 0

  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const handler = () => setScrolled(el.scrollTop > 64)
    el.addEventListener('scroll', handler, { passive: true })
    return () => el.removeEventListener('scroll', handler)
  }, [])

  return (
    <div ref={scrollRef} className="h-full overflow-y-auto">
      <Header scrolled={scrolled} />

      <div className="px-6 pb-8 pt-2">
        <h1 className="text-3xl font-black text-white mb-5">Search</h1>

        <SearchBar
          value={query}
          onChange={setQuery}
          autoFocus
          className="max-w-md mb-8"
        />

        {/* Loading indicator */}
        {isLoading && (
          <div className="flex items-center gap-2 text-[#b3b3b3] mb-6">
            <Loader2 size={16} className="animate-spin" />
            <span className="text-sm">Searching...</span>
          </div>
        )}

        {/* Search results */}
        {hasResults && !isLoading && (
          <div className="space-y-8">
            {/* Songs */}
            {results.songs.length > 0 && (
              <section>
                <h2 className="text-xl font-black text-white mb-4">Songs</h2>
                <div className="space-y-1">
                  {results.songs.map((song, i) => (
                    <SongCard
                      key={song.id}
                      song={song}
                      queue={results.songs}
                      variant="row"
                      index={i + 1}
                      showAlbum
                    />
                  ))}
                </div>
              </section>
            )}

            {/* Artists */}
            {results.artists.length > 0 && (
              <section>
                <h2 className="text-xl font-black text-white mb-4">Artists</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {results.artists.map((artist: any) => (
                    <ArtistCard key={artist.id} artist={artist} />
                  ))}
                </div>
              </section>
            )}

            {/* Albums */}
            {results.albums.length > 0 && (
              <section>
                <h2 className="text-xl font-black text-white mb-4">Albums</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {results.albums.map((album: any) => (
                    <AlbumCard key={album.id} album={album} />
                  ))}
                </div>
              </section>
            )}

            {/* No results */}
            {results.songs.length === 0 && results.artists.length === 0 && results.albums.length === 0 && (
              <div className="text-center py-16">
                <p className="text-white text-lg font-bold mb-2">No results found for "{query}"</p>
                <p className="text-[#b3b3b3] text-sm">
                  Please check your spelling or try different keywords.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Browse genres (default state) */}
        {!hasResults && (
          <div>
            <h2 className="text-xl font-black text-white mb-4">Browse all</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {GENRE_TILES.map(({ label, color }) => (
                <button
                  key={label}
                  onClick={() => setQuery(label)}
                  className={`bg-gradient-to-br ${color} rounded-lg p-4 text-left h-24 overflow-hidden relative hover:scale-105 transition-transform duration-200`}
                >
                  <span className="text-white font-black text-base">{label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
