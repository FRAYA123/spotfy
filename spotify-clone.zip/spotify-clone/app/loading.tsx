import { GridSkeleton } from '@/components/ui/Skeleton'

export default function Loading() {
  return (
    <div className="px-6 py-8">
      <div className="h-8 w-48 bg-[#282828] rounded animate-pulse mb-8" />
      <GridSkeleton count={6} />
    </div>
  )
}
