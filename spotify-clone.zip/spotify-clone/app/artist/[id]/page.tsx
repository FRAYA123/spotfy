import { getArtistById } from '@/lib/queries'
import { ArtistPageClient } from '@/components/ui/ArtistPageClient'
import { notFound } from 'next/navigation'

interface Props {
  params: { id: string }
}

export default async function ArtistPage({ params }: Props) {
  const result = await getArtistById(params.id)
  if (!result) notFound()
  return <ArtistPageClient artist={result.artist} songs={result.songs} albums={result.albums as any} />
}
