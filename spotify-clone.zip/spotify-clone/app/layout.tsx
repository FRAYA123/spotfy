import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Sidebar } from '@/components/layout/Sidebar'
import { PlayerBar } from '@/components/layout/PlayerBar'
import { createServerSupabaseClient } from '@/lib/supabase-server'
import { getUserPlaylists } from '@/lib/queries'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Sportify – Music for Everyone',
  description: 'Listen to your favorite songs, albums and artists.',
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const supabase = await createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()

  const playlists = user ? await getUserPlaylists(user.id).catch(() => []) : []

  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-[#121212] text-white antialiased`}>
        <div className="flex h-screen overflow-hidden">
          {/* Sidebar */}
          <Sidebar playlists={playlists} />

          {/* Main content */}
          <div className="flex flex-col flex-1 overflow-hidden">
            <main className="flex-1 overflow-y-auto">
              {children}
            </main>
            <PlayerBar />
          </div>
        </div>
      </body>
    </html>
  )
}
