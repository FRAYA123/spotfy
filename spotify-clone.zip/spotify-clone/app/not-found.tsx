import Link from 'next/link'
import { Music2 } from 'lucide-react'

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center min-h-full py-20 text-center px-4">
      <Music2 size={64} className="text-[#535353] mb-6" />
      <h1 className="text-5xl font-black text-white mb-4">404</h1>
      <p className="text-[#b3b3b3] text-lg mb-2">Page not found</p>
      <p className="text-[#535353] text-sm mb-8">
        The page you're looking for doesn't exist or has been moved.
      </p>
      <Link
        href="/"
        className="bg-white hover:bg-gray-100 text-black font-bold text-sm px-8 py-3 rounded-full transition-colors"
      >
        Go Home
      </Link>
    </div>
  )
}
