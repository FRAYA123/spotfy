import { createServerSupabaseClient } from '@/lib/supabase-server'
import { getPlaylistById } from '@/lib/queries'
import { PlaylistClient } from '@/components/ui/PlaylistClient'
import { notFound } from 'next/navigation'

interface Props {
  params: { id: string }
}

export default async function PlaylistPage({ params }: Props) {
  const supabase = await createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()

  const result = await getPlaylistById(params.id)
  if (!result) notFound()

  return (
    <PlaylistClient
      playlist={result.playlist}
      songs={result.songs}
      userId={user?.id}
    />
  )
}
