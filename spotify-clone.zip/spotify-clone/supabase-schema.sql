-- ============================================================
-- Sportify – Full Database Schema
-- Run this in Supabase SQL Editor
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── Artists ─────────────────────────────────────────────────
CREATE TABLE artists (
  id               UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name             TEXT NOT NULL,
  bio              TEXT,
  image_url        TEXT,
  verified         BOOLEAN DEFAULT false,
  monthly_listeners INT DEFAULT 0,
  created_at       TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Albums ──────────────────────────────────────────────────
CREATE TABLE albums (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title        TEXT NOT NULL,
  artist_id    UUID REFERENCES artists(id) ON DELETE SET NULL,
  cover_url    TEXT,
  release_year INT,
  genre        TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Songs ───────────────────────────────────────────────────
CREATE TABLE songs (
  id           UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title        TEXT NOT NULL,
  artist_id    UUID REFERENCES artists(id) ON DELETE SET NULL,
  album_id     UUID REFERENCES albums(id) ON DELETE SET NULL,
  duration     INT NOT NULL DEFAULT 0,   -- seconds
  audio_url    TEXT NOT NULL,
  cover_url    TEXT,
  track_number INT,
  play_count   INT DEFAULT 0,
  is_explicit  BOOLEAN DEFAULT false,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Full-text search index on songs
CREATE INDEX idx_songs_title_fts
  ON songs USING gin(to_tsvector('english', title));
CREATE INDEX idx_songs_artist_id ON songs(artist_id);
CREATE INDEX idx_songs_album_id  ON songs(album_id);

-- ─── Playlists ────────────────────────────────────────────────
CREATE TABLE playlists (
  id          UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id     UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  description TEXT,
  cover_url   TEXT,
  is_public   BOOLEAN DEFAULT true,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_playlists_user ON playlists(user_id);

-- ─── Playlist Songs (pivot) ───────────────────────────────────
CREATE TABLE playlist_songs (
  playlist_id UUID REFERENCES playlists(id) ON DELETE CASCADE,
  song_id     UUID REFERENCES songs(id)     ON DELETE CASCADE,
  position    INT NOT NULL DEFAULT 0,
  added_at    TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (playlist_id, song_id)
);

-- ─── Liked Songs ─────────────────────────────────────────────
CREATE TABLE liked_songs (
  user_id    UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  song_id    UUID REFERENCES songs(id)      ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (user_id, song_id)
);

CREATE INDEX idx_liked_user ON liked_songs(user_id);

-- ============================================================
-- Row Level Security
-- ============================================================

-- Songs: public read, authenticated write
ALTER TABLE songs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Songs are publicly readable" ON songs
  FOR SELECT USING (true);
CREATE POLICY "Authenticated users can insert songs" ON songs
  FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- Artists: public read
ALTER TABLE artists ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Artists are publicly readable" ON artists
  FOR SELECT USING (true);

-- Albums: public read
ALTER TABLE albums ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Albums are publicly readable" ON albums
  FOR SELECT USING (true);

-- Playlists: public read for public playlists, owner full access
ALTER TABLE playlists ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public playlists are readable" ON playlists
  FOR SELECT USING (is_public = true OR auth.uid() = user_id);
CREATE POLICY "Users manage own playlists" ON playlists
  FOR ALL USING (auth.uid() = user_id);

-- Playlist songs: readable if playlist is readable
ALTER TABLE playlist_songs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Playlist songs readable" ON playlist_songs
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM playlists
      WHERE id = playlist_id
      AND (is_public = true OR user_id = auth.uid())
    )
  );
CREATE POLICY "Playlist owners manage songs" ON playlist_songs
  FOR ALL USING (
    EXISTS (
      SELECT 1 FROM playlists
      WHERE id = playlist_id AND user_id = auth.uid()
    )
  );

-- Liked songs: private to owner
ALTER TABLE liked_songs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own likes" ON liked_songs
  FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- Helper Functions
-- ============================================================

-- Increment play count safely
CREATE OR REPLACE FUNCTION increment_play_count(song_id UUID)
RETURNS void AS $$
  UPDATE songs SET play_count = play_count + 1 WHERE id = song_id;
$$ LANGUAGE sql SECURITY DEFINER;

-- ============================================================
-- Storage Buckets (run in Supabase Storage UI or SQL)
-- ============================================================
-- INSERT INTO storage.buckets (id, name, public) VALUES ('songs', 'songs', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('artists', 'artists', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('playlists', 'playlists', true);

-- Storage policies for 'songs' bucket
-- CREATE POLICY "Public read songs storage" ON storage.objects FOR SELECT USING (bucket_id = 'songs');
-- CREATE POLICY "Auth users upload songs"   ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'songs' AND auth.role() = 'authenticated');

-- ============================================================
-- Sample seed data (optional)
-- ============================================================
INSERT INTO artists (name, bio, verified, monthly_listeners) VALUES
  ('Tulus', 'Indonesian singer-songwriter known for soulful pop music.', true, 5200000),
  ('Pamungkas', 'Indie pop artist from Jakarta with a unique storytelling style.', true, 3800000),
  ('Kunto Aji', 'Indie musician blending pop and introspective lyrics.', true, 2100000);
