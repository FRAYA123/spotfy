'use client'

import { useEffect, useRef } from 'react'
import { usePlayerStore } from '@/store/usePlayerStore'

export function usePlayer() {
  const audioRef = useRef<HTMLAudioElement | null>(null)
  const store = usePlayerStore()

  // Initialize audio element once
  useEffect(() => {
    if (typeof window === 'undefined') return
    if (!audioRef.current) {
      audioRef.current = new Audio()
      audioRef.current.preload = 'metadata'
    }
    const audio = audioRef.current

    function onTimeUpdate() {
      store.setProgress(audio.currentTime)
    }
    function onDurationChange() {
      store.setDuration(audio.duration || 0)
    }
    function onEnded() {
      store.onSongEnd()
    }
    function onCanPlay() {
      if (store.isPlaying) audio.play().catch(() => {})
    }

    audio.addEventListener('timeupdate', onTimeUpdate)
    audio.addEventListener('durationchange', onDurationChange)
    audio.addEventListener('ended', onEnded)
    audio.addEventListener('canplay', onCanPlay)

    return () => {
      audio.removeEventListener('timeupdate', onTimeUpdate)
      audio.removeEventListener('durationchange', onDurationChange)
      audio.removeEventListener('ended', onEnded)
      audio.removeEventListener('canplay', onCanPlay)
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // Sync song source
  useEffect(() => {
    const audio = audioRef.current
    if (!audio || !store.currentSong) return
    audio.src = store.currentSong.audio_url
    audio.load()
    if (store.isPlaying) {
      audio.play().catch(() => {})
    }
  }, [store.currentSong?.id]) // eslint-disable-line react-hooks/exhaustive-deps

  // Sync play/pause
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return
    if (store.isPlaying) {
      audio.play().catch(() => {})
    } else {
      audio.pause()
    }
  }, [store.isPlaying])

  // Sync volume
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return
    audio.volume = store.isMuted ? 0 : store.volume
  }, [store.volume, store.isMuted])

  // Seek when progress is set programmatically (clicking progress bar)
  const seek = (seconds: number) => {
    const audio = audioRef.current
    if (!audio) return
    audio.currentTime = seconds
    store.setProgress(seconds)
  }

  return {
    ...store,
    seek,
    audioRef,
  }
}
