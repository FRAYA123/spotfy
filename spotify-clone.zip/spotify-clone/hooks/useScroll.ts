'use client'

import { useState, useEffect, useRef } from 'react'

export function useScroll(threshold: number = 64) {
  const [scrolled, setScrolled] = useState(false)
  const [scrollY, setScrollY] = useState(0)
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = ref.current
    if (!container) return

    function onScroll() {
      const y = container!.scrollTop
      setScrollY(y)
      setScrolled(y > threshold)
    }

    container.addEventListener('scroll', onScroll, { passive: true })
    return () => container.removeEventListener('scroll', onScroll)
  }, [threshold])

  return { scrolled, scrollY, ref }
}
