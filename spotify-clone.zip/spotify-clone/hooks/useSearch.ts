'use client'

import { useState, useEffect } from 'react'
import { useDebounce } from './useDebounce'
import { searchAll } from '@/lib/queries'
import { Song, Artist, Album } from '@/types'

interface SearchResults {
  songs: Song[]
  artists: Artist[]
  albums: Album[]
}

export function useSearch() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResults>({ songs: [], artists: [], albums: [] })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const debouncedQuery = useDebounce(query, 350)

  useEffect(() => {
    if (!debouncedQuery.trim()) {
      setResults({ songs: [], artists: [], albums: [] })
      setIsLoading(false)
      return
    }

    const controller = new AbortController()

    async function doSearch() {
      setIsLoading(true)
      setError(null)
      try {
        const data = await searchAll(debouncedQuery)
        if (!controller.signal.aborted) {
          setResults(data)
        }
      } catch (err) {
        if (!controller.signal.aborted) {
          setError('Search failed. Please try again.')
        }
      } finally {
        if (!controller.signal.aborted) {
          setIsLoading(false)
        }
      }
    }

    doSearch()
    return () => controller.abort()
  }, [debouncedQuery])

  return { query, setQuery, results, isLoading, error }
}
