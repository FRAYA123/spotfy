export interface Artist {
  id: string
  name: string
  bio?: string
  image_url?: string
  verified: boolean
  monthly_listeners: number
  created_at: string
}

export interface Album {
  id: string
  title: string
  artist_id: string
  cover_url?: string
  release_year?: number
  genre?: string
  created_at: string
  artists?: Artist
}

export interface Song {
  id: string
  title: string
  artist_id?: string
  album_id?: string
  duration: number
  audio_url: string
  cover_url?: string
  track_number?: number
  play_count: number
  is_explicit: boolean
  created_at: string
  artists?: Artist
  albums?: Album
}

export interface Playlist {
  id: string
  user_id: string
  name: string
  description?: string
  cover_url?: string
  is_public: boolean
  created_at: string
  playlist_songs?: { songs: Song }[]
}

export interface LikedSong {
  user_id: string
  song_id: string
  created_at: string
  songs?: Song
}

export type RepeatMode = 'none' | 'all' | 'one'

export interface User {
  id: string
  email?: string
  user_metadata?: {
    full_name?: string
    avatar_url?: string
  }
}
