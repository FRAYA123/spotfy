# 🎵 Sportify — Spotify Clone

A full-stack music streaming web app built with **Next.js 14**, **Supabase**, **Zustand**, and **Tailwind CSS**.

---

## ✨ Features

- 🎵 **Music Player** — Play/Pause, Next/Previous, Seek, Volume, Shuffle, Repeat (none/all/one)
- 🔍 **Real-time Search** — Debounced search across songs, artists, albums
- 📚 **Library** — Liked songs & personal playlists
- 💚 **Like System** — Optimistic UI like/unlike songs
- 📤 **Upload** — Upload MP3 + cover art to Supabase Storage
- 🔐 **Auth** — Supabase Auth (email/password) with protected routes
- 📱 **Responsive** — Desktop sidebar + mobile bottom nav
- 🎨 **Spotify-style UI** — `#121212` bg, `#1DB954` green accents, hover play buttons

---

## 🚀 Getting Started

### 1. Clone & Install

```bash
git clone <your-repo>
cd spotify-clone
npm install
```

### 2. Create Supabase Project

1. Go to [supabase.com](https://supabase.com) → New Project
2. Copy your **Project URL** and **anon public key**

### 3. Environment Variables

Create `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
```

### 4. Run the Database Schema

In Supabase → **SQL Editor**, paste and run `supabase-schema.sql`.

### 5. Create Storage Buckets

In Supabase → **Storage**, create three public buckets:
- `songs` — for MP3 audio files and cover images
- `artists` — for artist profile images
- `playlists` — for playlist covers

Then add storage policies for each bucket:
```sql
-- Allow public reads
CREATE POLICY "Public read" ON storage.objects FOR SELECT USING (bucket_id = 'songs');
-- Allow authenticated uploads
CREATE POLICY "Auth upload" ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'songs' AND auth.role() = 'authenticated');
```

### 6. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 📁 Project Structure

```
spotify-clone/
├── app/                        # Next.js 14 App Router
│   ├── layout.tsx              # Root layout + Sidebar + PlayerBar
│   ├── page.tsx                # Home dashboard
│   ├── (auth)/
│   │   ├── login/page.tsx
│   │   └── signup/page.tsx
│   ├── search/page.tsx         # Real-time search
│   ├── library/page.tsx        # Liked songs + playlists
│   ├── album/[id]/page.tsx
│   ├── artist/[id]/page.tsx
│   ├── playlist/[id]/page.tsx
│   └── api/
│       ├── songs/route.ts      # GET/DELETE songs
│       └── upload/route.ts     # POST upload MP3
│
├── components/
│   ├── layout/
│   │   ├── Sidebar.tsx         # Left navigation
│   │   ├── Header.tsx          # Transparent → opaque on scroll
│   │   ├── PlayerBar.tsx       # Sticky bottom player
│   │   └── MobileNav.tsx       # Mobile bottom tabs
│   └── ui/
│       ├── SongCard.tsx        # Card + row variants, hover play
│       ├── AlbumCard.tsx
│       ├── ArtistCard.tsx
│       ├── SearchBar.tsx
│       ├── LikeButton.tsx      # Optimistic toggle
│       ├── UploadForm.tsx      # MP3 + cover upload
│       ├── HomeFeed.tsx
│       ├── LibraryClient.tsx
│       ├── PlaylistClient.tsx
│       ├── AlbumClient.tsx
│       └── ArtistPageClient.tsx
│
├── hooks/
│   ├── usePlayer.ts            # Audio element bridge
│   ├── usePlayerStore.ts       # ← import this elsewhere if needed
│   ├── useSearch.ts            # Debounced search
│   ├── useAuth.ts              # Current user
│   ├── useDebounce.ts
│   └── useScroll.ts
│
├── store/
│   └── usePlayerStore.ts       # Zustand player state
│
├── lib/
│   ├── supabase.ts             # Browser client
│   ├── supabase-server.ts      # Server client (RSC)
│   ├── queries.ts              # All DB fetch functions
│   ├── upload.ts               # Storage upload helpers
│   └── utils.ts                # cn(), formatTime(), etc.
│
├── types/
│   └── index.ts                # Song, Artist, Album, Playlist
│
├── middleware.ts               # Auth guard
├── supabase-schema.sql         # Full DB schema + RLS + seed
├── tailwind.config.ts
├── next.config.ts
└── package.json
```

---

## 🎮 Usage

### Playing Music
```tsx
import { usePlayerStore } from '@/store/usePlayerStore'

const { playSong } = usePlayerStore()

// Play a single song
playSong(song)

// Play from a queue (album/playlist)
playSong(song, allSongs)
```

### Liking a Song
```tsx
import { LikeButton } from '@/components/ui/LikeButton'

<LikeButton songId={song.id} userId={user.id} initialLiked={isLiked} />
```

### Uploading a Song
Navigate to the upload form component or POST to `/api/upload` with `FormData`:
```
audio  — MP3 File (required)
title  — string (required)
duration — number in seconds (required)
cover  — image File (optional)
artist_id — UUID (optional)
album_id  — UUID (optional)
```

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 14 (App Router) |
| Styling | Tailwind CSS |
| Icons | Lucide React |
| State | Zustand (with persistence) |
| Database | Supabase (PostgreSQL) |
| Auth | Supabase Auth |
| Storage | Supabase Storage |
| Language | TypeScript |

---

## 📦 Key Dependencies

```json
{
  "next": "14.x",
  "zustand": "^4.5",
  "@supabase/supabase-js": "^2.43",
  "@supabase/ssr": "^0.4",
  "lucide-react": "^0.383",
  "clsx": "^2.1",
  "tailwind-merge": "^2.3"
}
```

---

## 🔧 Customization

- **Colors**: Edit `--spotify-green` in `globals.css`
- **Seed data**: Uncomment the seed section in `supabase-schema.sql`
- **Add genres**: Edit `GENRE_TILES` array in `app/search/page.tsx`
- **Add upload page**: Create `app/upload/page.tsx` and use `<UploadForm />`

---

## 📄 License

MIT
