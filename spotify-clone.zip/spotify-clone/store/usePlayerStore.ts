'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { Song, RepeatMode } from '@/types'

interface PlayerState {
  // State
  currentSong: Song | null
  queue: Song[]
  originalQueue: Song[]
  currentIndex: number
  isPlaying: boolean
  volume: number
  progress: number
  duration: number
  isShuffle: boolean
  repeatMode: RepeatMode
  isMuted: boolean
  isExpanded: boolean

  // Actions
  playSong: (song: Song, queue?: Song[]) => void
  togglePlay: () => void
  playNext: () => void
  playPrev: () => void
  setVolume: (v: number) => void
  setProgress: (p: number) => void
  setDuration: (d: number) => void
  toggleShuffle: () => void
  cycleRepeat: () => void
  toggleMute: () => void
  addToQueue: (song: Song) => void
  clearQueue: () => void
  toggleExpanded: () => void
  onSongEnd: () => void
}

function shuffleArray(arr: Song[], activeIdx: number): Song[] {
  const active = arr[activeIdx]
  const rest = arr.filter((_, i) => i !== activeIdx)
  for (let i = rest.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [rest[i], rest[j]] = [rest[j], rest[i]]
  }
  return [active, ...rest]
}

export const usePlayerStore = create<PlayerState>()(
  persist(
    (set, get) => ({
      currentSong: null,
      queue: [],
      originalQueue: [],
      currentIndex: 0,
      isPlaying: false,
      volume: 0.8,
      progress: 0,
      duration: 0,
      isShuffle: false,
      repeatMode: 'none',
      isMuted: false,
      isExpanded: false,

      playSong: (song, queue = []) => {
        const finalQueue = queue.length > 0 ? queue : [song]
        const idx = finalQueue.findIndex(s => s.id === song.id)
        const { isShuffle } = get()

        set({
          currentSong: song,
          originalQueue: finalQueue,
          queue: isShuffle ? shuffleArray(finalQueue, Math.max(0, idx)) : finalQueue,
          currentIndex: isShuffle ? 0 : Math.max(0, idx),
          isPlaying: true,
          progress: 0,
        })
      },

      togglePlay: () => set(s => ({ isPlaying: !s.isPlaying })),

      playNext: () => {
        const { queue, currentIndex, repeatMode } = get()
        if (repeatMode === 'one') {
          set({ progress: 0, isPlaying: true })
          return
        }
        const next = currentIndex + 1
        if (next >= queue.length) {
          if (repeatMode === 'all') {
            set({ currentIndex: 0, currentSong: queue[0], progress: 0, isPlaying: true })
          } else {
            set({ isPlaying: false, progress: 0 })
          }
          return
        }
        set({ currentIndex: next, currentSong: queue[next], progress: 0, isPlaying: true })
      },

      playPrev: () => {
        const { queue, currentIndex, progress } = get()
        // If more than 3s played, restart current song
        if (progress > 3) {
          set({ progress: 0 })
          return
        }
        const prev = Math.max(0, currentIndex - 1)
        set({ currentIndex: prev, currentSong: queue[prev], progress: 0, isPlaying: true })
      },

      onSongEnd: () => {
        const { repeatMode, playNext } = get()
        if (repeatMode === 'one') {
          set({ progress: 0, isPlaying: true })
        } else {
          playNext()
        }
      },

      setVolume: (v) => set({ volume: Math.max(0, Math.min(1, v)), isMuted: v === 0 }),
      setProgress: (p) => set({ progress: p }),
      setDuration: (d) => set({ duration: d }),
      toggleMute: () => set(s => ({ isMuted: !s.isMuted })),
      toggleExpanded: () => set(s => ({ isExpanded: !s.isExpanded })),

      toggleShuffle: () => {
        const { isShuffle, originalQueue, currentSong } = get()
        if (!isShuffle) {
          const idx = originalQueue.findIndex(s => s.id === currentSong?.id)
          set({ isShuffle: true, queue: shuffleArray(originalQueue, Math.max(0, idx)), currentIndex: 0 })
        } else {
          const idx = originalQueue.findIndex(s => s.id === currentSong?.id)
          set({ isShuffle: false, queue: originalQueue, currentIndex: Math.max(0, idx) })
        }
      },

      cycleRepeat: () => set(s => ({
        repeatMode: s.repeatMode === 'none' ? 'all' : s.repeatMode === 'all' ? 'one' : 'none'
      })),

      addToQueue: (song) => set(s => ({
        queue: [...s.queue, song],
        originalQueue: [...s.originalQueue, song],
      })),

      clearQueue: () => set({ queue: [], originalQueue: [], currentSong: null, isPlaying: false }),
    }),
    {
      name: 'spotify-player',
      partialize: (state) => ({
        volume: state.volume,
        isShuffle: state.isShuffle,
        repeatMode: state.repeatMode,
        isMuted: state.isMuted,
      }),
    }
  )
)
